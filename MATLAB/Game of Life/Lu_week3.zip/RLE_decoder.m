function mat = RLE_decoder(filename)
%Converts RLE file (the input) into a binary matrix (the output)

%Creates a cell array that contains the contents of the imported file
%Each cell is a new line
infile = importdata(filename);

%Extracts the x (num of columns) and y (num of rows) dimensions of the
%array
dimensions = regexp(infile{1}, '\d*', 'match');
c = str2double(dimensions{1});
r = str2double(dimensions{2});

%Creates the output array with dimensions as described in the file,
%initially with all values of zero
mat = zeros(r, c);

%----------------------Assumes that rule = B3/S23---------------------

%Cuts the expressions into cells of the form <run_count><tag> or '$' or '!'
substring = regexp(infile{2}, '\d*\D', 'match');

%Row and column counter for the output matrix in order to keep track
row = 1; col = 1;

%Traverses all cells in the substring
for i = 1:length(substring)

    %Case 1 ('!', end of process):
    if substring{i} == '!'
        %Fills row with zeros if the row hasn't been entirely filled yet
        if mod(col-1, c) ~= 0
            %Number of unfilled columns in that row
            num = c - mod(col-1, c);
            %Fills with dead cells
            mat(row, col:col+num-1) = 0;
        end
        %Terminates for loop, end of filling the matrix
        break;

    %Case 2 ('$', end of line):
    elseif substring{i} == '$'
        %Fills row with zeros if the row hasn't been entirely filled yet
        if mod(col-1, c) ~= 0
            %Number of unfilled columns in that row
            num = c - mod(col-1, c);
            %Fills with dead cells
            mat(row, col:col+num-1) = 0;
        end
        %Proceeds to next row
        col = 1;
        row = row + 1;

    %Case 3 (no run_count, which implies 1):
    elseif isletter(substring{i}(1))
        %Fills one "block" of the matrix according to the <tag>
        if substring{i}(1) == 'b'
            mat(row, col) = 0;
            col = col + 1;
        else
            mat(row, col) = 1;
            col = col + 1;
        end

    %Case 4 (<run_count><tag>):
    else
        %Stores the number of occurences of <tag>
        run_count = regexp(substring{i}, '\d*', 'match');
        num = str2double(run_count{1});
        %Stores the <tag>
        tag = regexp(substring{i}, '\D', 'match');
        %Fills <run_count> number of "blocks" of the matrix according to 
        %the <tag>
        if tag{1} == 'b'
            mat(row, col:col+num-1) = 0;
            col = col + num;
        else
            mat(row, col:col+num-1) = 1;
            col = col + num;
        end
    end

end

end