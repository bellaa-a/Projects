%I chose this pattern because it is the first known finite pattern with
%unbounded growth, which was really cool to think about. Also, the pattern
%shows how the blocks remain stable and how the "queen bee shuttles" act.
%The bullet-like 

gliding_gun = RLE_decoder('GosperGlidingGun.txt');
gliding_gun = padarray(gliding_gun, [50, 50]);

%Create a videowriter object
v = VideoWriter("lu_week2_bonus", 'MPEG-4');
%v.FrameRate = 200;
open(v);

%Run 600 generations
for i = 1:500
    %Find the matrix of each generation
    gliding_gun = GOL(gliding_gun);

    %Create the actual image
    lsd = imagesc(gliding_gun);
    colormap(gray)
    drawnow;

    %Get every frame
    frame(i) = getframe(gcf);

end

%Write the frame into the videowriter object
writeVideo(v,frame);

%Closes the opened object
close(v);