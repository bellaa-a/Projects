piHeptomino = [1, 1, 1; 
               1, 0, 1; 
               1, 0, 1];

piHeptomino = padarray(piHeptomino, [50, 50])

for i = 1:100
    piHeptomino = GOL(piHeptomino);
end

subplot(1, 2, 1)
imagesc(piHeptomino)
colormap(gray)



traffic_jam = RLE_decoder('trafficjam.txt');
traffic_jam = padarray(traffic_jam, [20, 20]);

for i = 1:23
    traffic_jam = GOL(traffic_jam);
end

subplot(1, 2, 2)
imagesc(traffic_jam)
colormap(gray)