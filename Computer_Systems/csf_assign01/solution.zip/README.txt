TODO: add information about contributions of team member(s)
MS 1:
    Bella Lu:
        Writing Functions:
            uint256_get_bits
            uint256_is_bit_set
        Unit Test:
            uint256_is_bit_set
            uint256_create_from_u32
            uint256_create

    Kyle Kim:
        Writing Functions:
            uint256_create_from_u32
            uint256_create
        Unit Test:
            uint256_get_bits

MS 2:
    Bella Lu:
        Writing Functions:
            uint256_sub
            uint256_negate
            uint256_mul
            uint256_lshift
        Unit Test:
            uint256_negate
            uint256_lshift
    Kyle Kim:
        Writing Functions:
            uint256_create_from_hex
            uint256_format_as_hex
            uint256_add
        Unit Test:
            uint256_create_from_hex
            uint256_format_as_hex
            uint256_add
            uint256_sub
            uint256_mul
