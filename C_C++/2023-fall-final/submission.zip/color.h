//Zi Yun Mao zmao16
//Bella Lu xlu62
//Ava Venuti avenuti1

#ifndef COLOR_H
#define COLOR_H

#include <cstdint>
#include <cassert>

struct Color {
  uint8_t r, g, b;
};

#endif // COLOR_H
