//Bella Lu
//xlu62

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <iostream>
#include <tuple>
#include <vector>
#include <algorithm>
#include "language_model.h"

using std::tuple; using std::make_tuple;
using std::get;
using std::cout; using std::endl;
using std::string;
using std::vector;
using std::ifstream;
using std::cerr;

int main (int argc, char *argv[]) {
    if (argc < 3) {
        cerr << "Invalid command: valid options are a, d, c, and f" << endl;
        return 1;
    } 
    bool found = false;
    int count = 0;
    vector<trigram> trigram_list;
    ifstream infile(argv[1]);
    if (!infile.is_open()) {
        cerr << "Invalid file list: " << argv[1] << endl;
        return 1;
    }
    string file;
    vector<string> filenames;
    while (infile >> file) {
        filenames.push_back(file);
        ifstream text(file);
        if (!text.is_open()) {
            cerr << "Invalid file: " << file << endl;
            count++;
        } else {
            vector<string> words;
            words.push_back("<START_1>");
            words.push_back("<START_2>");
            string word;
            while (text >> word) {
                words.push_back(word);
            }
            words.push_back("<END_1>");
            words.push_back("<END_2>");
            for (int i = 0; i < (int)words.size() - 2; i++) {
                found = false;
                trigram temp_trigram = make_tuple(words[i], words[i+1], words[i+2], 1);
                for (int j = 0; j < (int)trigram_list.size(); j++) {
                    if (get<0>(trigram_list[j]) == get<0>(temp_trigram) 
                    && get<1>(trigram_list[j]) == get<1>(temp_trigram) 
                    && get<2>(trigram_list[j]) == get<2>(temp_trigram)) {
                        get<3>(trigram_list[j])++;
                        found = true;
                    }
                }
                if (!found) {
                    trigram_list.push_back(temp_trigram);
                }
            }

        }
    }
    if (count == (int)filenames.size()) {
        return 1;
    }
    if (*argv[2] == 'a') {
        handle_a_command(trigram_list); 
    } else if (*argv[2] == 'd') {
        handle_d_command(trigram_list);
    } else if (*argv[2] == 'c') {
        handle_c_command(trigram_list);
    } else if (*argv[2] == 'f') {
        if (argc != 5) {
            cerr << "Invalid argument list: f requires two additional command-line arguments" << endl;
            return 1;
        }
        handle_f_command(trigram_list, argv[3], argv[4]);
    } else { 
        cerr << "Invalid command: valid options are a, d, c, and f" << endl;
        return 1;
    }
    return 0;
}