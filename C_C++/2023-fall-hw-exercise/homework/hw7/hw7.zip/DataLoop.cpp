#include "DataLoop.h"

//Default Constructor:
DataLoop::DataLoop() : start(nullptr), count(0) {};

//Alternative Constructor
DataLoop::DataLoop(const int & num) : start(new _Node({num, nullptr, nullptr})), count(1) {
    start->next = start;
    start->prev = start;
  }

//Copy Constructor
DataLoop::DataLoop(const DataLoop & rhs) : DataLoop() {
    *this = rhs;
  }

//Overloaded operator=
DataLoop & DataLoop::operator=(const DataLoop & rhs) {
    _Node* cur = rhs.start;
    if (this != &rhs) {
        clear();
        for (size_t i = 0; i < rhs.count; i++) {
            *this += cur->data;
            cur = cur->next;
        }
    }
    count = rhs.count;
    return *this;
}

//Destructor
DataLoop::~DataLoop() {
    clear();
}

//Overloaded operator==
bool DataLoop::operator==(const DataLoop & rhs) const {
    _Node* cur = start;
    _Node* other = rhs.start;
    size_t larger_count = count;
    if (count < rhs.count) {
        larger_count = rhs.count;
    } else {
        larger_count = count;
    }

    for (size_t i = 0; i < larger_count; i++) {
        if (other->data != cur->data) {
            return false;
        }
        cur = cur->next;
        other = other->next;
    }
    return true;
}


DataLoop & DataLoop::operator+=(const int & num) {
    _Node* new_node = new _Node({num, nullptr, nullptr});
    if (!new_node) {  //allocation failed
	    return *this; 
    }
    if (start == nullptr) {
        start = new_node;
        start->prev = start;
        start->next = start;
        count++;
    } else if (start->prev != nullptr && start->next != nullptr) {
        start->prev->next = new_node;
        new_node->prev = start->prev;
        start->prev = new_node;
        new_node->next = start;
        count++;
    }
    return *this;
  }

//Overloaded operator+
 DataLoop DataLoop::operator+(const DataLoop & rhs) const {
    DataLoop new_loop;
    _Node* cur = start;
    for (size_t i = 0; i < count; i++) {
        new_loop += cur->data;
        cur = cur->next;
    }
    
    cur = rhs.start;
    for (size_t i = 0; i < rhs.count; i++) {
        new_loop += cur->data;
        cur = cur->next;
    }
    
    new_loop.count = this->count + rhs.count;
    return new_loop;
}

//Overloaded oerator^
DataLoop & DataLoop::operator^(int offset) {
    if (offset == 0) {
        return *this;
    }
    if (offset > 0) {
        for (int i = 0; i < offset; i++) {
            _Node* temp = start;
            start = start->next;
            start->prev = temp;
        }
    } else if (offset < 0) {
        for (int j = 0; j > offset; j--) {
            _Node* temp = start;
            start = start->prev;
            start->next = temp;
        }
    }
    return *this;
}

//Splice
DataLoop & DataLoop::splice(DataLoop & rhs, size_t pos) {
    *this ^ (pos - 1);

    _Node* this_temp = start->next;
    _Node* rhs_temp = rhs.start->prev;
    start->next = rhs.start;
    rhs.start->prev = start;
    this_temp->prev = rhs_temp;
    rhs_temp->next = this_temp;

    size_t position = pos % count;
    count += rhs.count;
    *this ^ (count - position + 1);

    rhs.start = nullptr;
    rhs.count = 0;
    return *this;
}

//Printing
std::ostream & operator<<(std::ostream & os, const DataLoop & dl) {
    if (dl.count == 0) {
        os << ">no values<";
    } else {
        DataLoop::_Node* cur = dl.start;
        for (size_t i = 0; i < dl.count; i++) {
            os << "-> " << cur->data << " <-";
            cur = cur->next;
        }
    }
    return os;
}

void DataLoop::clear() {
    _Node *temp;
  int size = count;

  while (size > 0 && start != nullptr)
  {
    temp = start;
    start = start->next;
    size--;
    delete temp;
  }

  start = nullptr;
  count = 0;
}