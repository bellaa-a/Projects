#ifndef STRING_FUNCTIONS_H
#define STRING_FUNCITONS_H

int concat(const char word1[], const char word2[], char result[], int result_capacity);

#endif